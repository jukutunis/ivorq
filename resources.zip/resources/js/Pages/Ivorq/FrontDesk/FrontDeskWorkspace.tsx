import React, { useState } from 'react';
import '../../../../css/ivorq-prototype.css';

import { frontDeskData } from '../../../data/ivorq/frontDesk';
import AppTopbar from '../../../Components/Ivorq/shell/AppTopbar';
import WorkspaceHeader from '../../../Components/Ivorq/workspace/WorkspaceHeader';
import ModuleTabs from '../../../Components/Ivorq/workspace/ModuleTabs';
import SplitLayout from '../../../Components/Ivorq/workspace/SplitLayout';
import MainContent from '../../../Components/Ivorq/workspace/MainContent';
import QuickFilterPanel from '../../../Components/Ivorq/patterns/QuickFilterPanel';
import OperationalSnapshot from '../../../Components/Ivorq/patterns/OperationalSnapshot';
import SnapshotCard from '../../../Components/Ivorq/patterns/SnapshotCard';
import AttentionArea from '../../../Components/Ivorq/patterns/AttentionArea';
import AttentionCard from '../../../Components/Ivorq/patterns/AttentionCard';
import QueueList from '../../../Components/Ivorq/patterns/QueueList';
import QueueItem from '../../../Components/Ivorq/patterns/QueueItem';

export default function FrontDeskWorkspace() {
  const [activeTab, setActiveTab] = useState('arrivals');

  const tabs = [
    { id: 'arrivals', label: 'Arrivals', badge: 24 },
    { id: 'departures', label: 'Departures', badge: 18 },
    { id: 'in_house', label: 'In House', badge: 142 },
    { id: 'room_readiness', label: 'Room Readiness' },
    { id: 'reservation_board', label: 'Reservation Board' },
  ];

  return (
    <>
      <AppTopbar />
      <div className="workspace">
        <WorkspaceHeader title="Guest Arrival Operations">
          <button className="btn btn-secondary">
            <svg className="icon" viewBox="0 0 24 24"><polyline points="1 4 1 10 7 10"></polyline><polyline points="23 20 23 14 17 14"></polyline><path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10M22 14l-4.64 4.36A9 9 0 0 1 3.51 15"></path></svg> Refresh
          </button>
          <button className="btn btn-secondary">
            <svg className="icon" viewBox="0 0 24 24"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg> Print
          </button>
          <button className="btn btn-secondary">
            <svg className="icon" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M16 13H8"/><path d="M16 17H8"/><path d="M10 9H8"/></svg> Export PDF
          </button>
          <button className="btn btn-secondary">
            <svg className="icon" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="m8 13 4 4"/><path d="m8 17 4-4"/></svg> Export XLSX
          </button>
          <button className="btn btn-secondary">
            <svg className="icon" viewBox="0 0 24 24"><path d="M15 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8" cy="7" r="4"/><path d="M18 8v6"/><path d="M21 11h-6"/></svg> Walk-In
          </button>
          <button className="btn btn-primary">
            <svg className="icon" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/><path d="M12 14v4"/><path d="M10 16h4"/></svg> New Reservation
          </button>
        </WorkspaceHeader>

        <ModuleTabs tabs={tabs} activeTabId={activeTab} onTabChange={setActiveTab} />

        <SplitLayout>
          <QuickFilterPanel>
            <div className="filter-group"><label className="filter-label">Search</label><input type="text" className="filter-input" placeholder="Guest, Res #, Room..." /></div>
            <div className="filter-group"><label className="filter-label">Arrival Date</label><input type="date" className="filter-input" defaultValue="2026-06-14" /></div>
            <div className="filter-group">
              <label className="filter-label">Status</label>
              <select className="filter-input">
                <option>All</option>
                <option>Due In</option>
                <option>Early Arrival</option>
              </select>
            </div>
            <div className="filter-group">
              <label className="filter-label">Payment</label>
              <select className="filter-input">
                <option>All</option>
                <option>Guaranteed</option>
                <option>Missing Guarantee</option>
              </select>
            </div>
            <div className="filter-group">
              <label className="filter-label">Room Readiness</label>
              <select className="filter-input">
                <option>All</option>
                <option>Ready</option>
                <option>Not Ready</option>
                <option>No Room Assigned</option>
              </select>
            </div>
          </QuickFilterPanel>

          <MainContent>
            <OperationalSnapshot>
              <SnapshotCard value={frontDeskData.snapshots.totalArrivals} label="Total Arrivals" />
              <SnapshotCard value={frontDeskData.snapshots.vipDueIn} label="VIP Due In" statusColor="vip-gold" />
              <SnapshotCard value={frontDeskData.snapshots.noRoomAssigned} label="No Room Assigned" statusColor="critical-red" />
              <SnapshotCard value={frontDeskData.snapshots.roomsNotReady} label="Rooms Not Ready" statusColor="warning-amber" />
            </OperationalSnapshot>

            <AttentionArea title="Arrival Attention Needed" badgeText={`${frontDeskData.attentionItems.length} Issues`} badgeType="warning" areaType="warning">
              {frontDeskData.attentionItems.map((item) => (
                <AttentionCard
                  key={item.id}
                  title={
                    <>
                      {item.badge && <span className="badge b-vip" style={{ marginRight: '4px' }}>{item.badge}</span>}
                      {item.title}
                    </>
                  }
                  meta={item.meta}
                  actions={item.actions.map((act, i) => (
                    <button key={i} className="btn btn-secondary btn-sm">{act}</button>
                  ))}
                />
              ))}
            </AttentionArea>

            <QueueList title="Check-In Queue" count={frontDeskData.checkInQueue.length}>
              {frontDeskData.checkInQueue.map((item) => (
                <QueueItem
                  key={item.id}
                  title={
                    <>
                      {item.name}
                      {item.vip && <span className="badge b-vip" style={{ fontSize: '11px', padding: '2px 6px', marginLeft: '6px' }}>VIP</span>}
                    </>
                  }
                  meta={
                    <>
                      <span style={{ color: 'var(--text-primary)', fontWeight: 500 }}>{item.roomType}</span> •{' '}
                      <span
                        style={{
                          fontWeight: 600,
                          color: item.roomStatusReady
                            ? 'var(--ready-green)'
                            : item.roomStatusWarning
                            ? 'var(--warning-amber)'
                            : item.roomStatusCritical
                            ? 'var(--critical-red)'
                            : 'inherit',
                        }}
                      >
                        {item.roomStatus}
                      </span>{' '}
                      • <span style={{ fontSize: '11px', opacity: 0.7 }}>{item.reservationId}</span>
                    </>
                  }
                  actions={item.actions.map((act, i) => (
                    <button
                      key={i}
                      className={act.includes('Start') ? 'btn btn-primary btn-sm' : 'btn btn-secondary btn-sm'}
                    >
                      {act}
                    </button>
                  ))}
                />
              ))}
            </QueueList>
          </MainContent>
        </SplitLayout>
      </div>
    </>
  );
}
