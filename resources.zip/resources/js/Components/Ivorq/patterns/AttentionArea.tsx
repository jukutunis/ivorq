import React from 'react';

interface AttentionAreaProps {
  title: string;
  badgeText: string;
  badgeType?: string; // 'warning', 'critical', etc.
  areaType?: string; // e.g. 'warning' for the yellow background
  children: React.ReactNode;
}

export default function AttentionArea({ title, badgeText, badgeType = 'warning', areaType = 'warning', children }: AttentionAreaProps) {
  const areaClass = areaType ? `attention-area ${areaType}` : 'attention-area';
  const badgeClass = `badge b-${badgeType}`;

  return (
    <div className={areaClass}>
      <div className="attention-header">
        <div className="attention-title">{title}</div>
        <div className={badgeClass}>{badgeText}</div>
      </div>
      {children}
    </div>
  );
}
