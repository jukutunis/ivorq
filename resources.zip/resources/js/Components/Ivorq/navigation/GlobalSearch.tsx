import React from 'react';

export default function GlobalSearch() {
  return (
    <div className="global-search-container">
      <svg className="icon global-search-icon" viewBox="0 0 24 24">
        <circle cx="11" cy="11" r="8"></circle>
        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
      </svg>
      <input
        type="text"
        className="global-search-input"
        placeholder="Search guests, rooms, work orders, inventory..."
      />
      <div className="global-search-shortcut">⌘K</div>
    </div>
  );
}
