import React from 'react';

export default function TopNav() {
  return (
    <nav className="topbar-nav">
      <div className="nav-item">
        <svg className="icon" style={{ color: '#94A3B8', marginRight: '6px' }} viewBox="0 0 24 24">
          <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
          <polyline points="9 22 9 12 15 12 15 22" />
        </svg>
        Home
      </div>
      <div className="nav-item active">
        <svg className="icon" style={{ color: '#3B82F6', marginRight: '6px' }} viewBox="0 0 24 24">
          <path d="M2 18h20" />
          <path d="M12 2v4" />
          <path d="M12 6a8 8 0 0 0-8 8v4h16v-4a8 8 0 0 0-8-8Z" />
        </svg>
        Front Desk
      </div>
      <div className="nav-item">
        <svg className="icon" style={{ color: '#10B981', marginRight: '6px' }} viewBox="0 0 24 24">
          <path d="m9.06 11.9 8.07-8.06a2.85 2.85 0 1 1 4.03 4.03l-8.06 8.08" />
          <path d="M7.07 14.94c-1.66 0-3 1.35-3 3.02 0 1.33-2.5 1.52-2 2.02 1.08 1.1 2.49 2.02 4 2.02 2.2 0 4-1.8 4-4.04a3.01 3.01 0 0 0-3-3.02z" />
        </svg>
        Housekeeping
      </div>
      <div className="nav-item">
        <svg className="icon" style={{ color: '#F97316', marginRight: '6px' }} viewBox="0 0 24 24">
          <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
        </svg>
        Engineering
      </div>
      <div className="nav-item">
        <svg className="icon" style={{ color: '#6366F1', marginRight: '6px' }} viewBox="0 0 24 24">
          <line x1="16.5" y1="9.4" x2="7.5" y2="4.21" />
          <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
          <polyline points="3.27 6.96 12 12.01 20.73 6.96" />
          <line x1="12" y1="22.08" x2="12" y2="12" />
        </svg>
        Inventory
      </div>
      <div className="nav-item">
        <svg className="icon" style={{ color: '#F59E0B', marginRight: '6px' }} viewBox="0 0 24 24">
          <circle cx="8" cy="21" r="1" />
          <circle cx="19" cy="21" r="1" />
          <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12" />
        </svg>
        Procurement
      </div>
      <div className="nav-item">
        <svg className="icon" style={{ color: '#8B5CF6', marginRight: '6px' }} viewBox="0 0 24 24">
          <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
          <circle cx="9" cy="7" r="4" />
          <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
          <path d="M16 3.13a4 4 0 0 1 0 7.75" />
        </svg>
        HRIS
      </div>
      <div className="nav-item">
        <svg className="icon" style={{ color: '#22C55E', marginRight: '6px' }} viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="10" />
          <path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8" />
          <path d="M12 18V6" />
        </svg>
        Finance
      </div>
      <div className="nav-item">
        <svg className="icon" style={{ color: '#06B6D4', marginRight: '6px' }} viewBox="0 0 24 24">
          <line x1="12" y1="20" x2="12" y2="10" />
          <line x1="18" y1="20" x2="18" y2="4" />
          <line x1="6" y1="20" x2="6" y2="14" />
        </svg>
        Reports
      </div>
      <div className="nav-item">
        <svg className="icon" style={{ color: '#A855F7', marginRight: '6px' }} viewBox="0 0 24 24">
          <path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3l1.9 5.8 1.9-5.8a2 2 0 0 1 1.3-1.3l5.8-1.9-5.8-1.9a2 2 0 0 1-1.3-1.3z" />
        </svg>
        AI Assistant
      </div>
    </nav>
  );
}
